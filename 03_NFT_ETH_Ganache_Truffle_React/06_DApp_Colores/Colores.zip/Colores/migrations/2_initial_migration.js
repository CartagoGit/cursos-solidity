const color = artifacts.require("color");

module.exports = function(deployer) {
  deployer.deploy(color);
};
